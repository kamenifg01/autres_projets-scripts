import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import random
import time
from enum import Enum

card_width = 150
card_height = 150

class Difficulty(Enum):
    debutant = 1
    intermediaire = 2
    expert = 3

class MemoryGame:
    def __init__(self, root, difficulty):
        self.root = root
        self.root.title("Memory Game")
        self.root.geometry("800x600")

        self.difficulty = difficulty

        self.time_limit = self.get_time_limit()
        self.timer_label = None

        self.difficulty_enum = self.get_difficulty_enum()
        self.start_time = time.time()

        self.cards_per_row = 5 if difficulty == "expert" else 4

        self.categories = ["Langage de programmation", "Base de données", "Sécurité informatique", "Réseaux informatiques", "Cloud", "Intelligence artificielle", "Science de données"]

        # Créer les boutons pour chaque carte avec des images
        self.image_paths = {}  # Dictionnaire pour stocker les chemins des images
        self.images = []  # Liste pour stocker les objets ImageTk
        self.buttons = []
        self.flipped_cards = []  # Ajout de l'initialisation des cartes retournées

        self.image_paths["?"] = ImageTk.PhotoImage(Image.open("decor.png").resize((card_width, card_height), Image.LANCZOS))

        for category in self.categories:
            image_path = f"{category.lower().replace(' ', '_')}.png"
            img = Image.open(image_path).resize((card_width, card_height), Image.LANCZOS)
            tk_img = ImageTk.PhotoImage(img)
            self.image_paths[category] = tk_img
            self.images.append(tk_img)

        self.cards = self.categories * 2
        random.shuffle(self.cards)

        # Configurer la géométrie pour centrer les boutons
        for i in range(self.calculate_rows() + 3):  # +1 pour le bouton de réinitialisation
            self.root.grid_rowconfigure(i, weight=1)
        for j in range(self.cards_per_row):
            self.root.grid_columnconfigure(j, weight=1)

        for i in range(self.calculate_rows()):
            for j in range(self.cards_per_row):
                index = i * self.cards_per_row + j
                button = tk.Button(root, image=self.image_paths["?"], width=card_width, height=card_height, command=lambda i=i, j=j: self.flip_card(i, j))
                button.grid(row=i, column=j, padx=5, pady=5)
                self.buttons.append(button)

        # Bouton de réinitialisation
        reset_button = tk.Button(root, text="Réinitialiser", command=self.reset_game, bg="red", fg="white")
        reset_button.grid(row=self.calculate_rows() + 3, column=0, columnspan=self.cards_per_row, pady=10)

        # Bouton pour arrêter la partie
        stop_button = tk.Button(root, text="Arrêter", command=self.stop_game, bg="#87CEFA", fg="white")
        stop_button.grid(row=self.calculate_rows() + 2, column=0, columnspan=self.cards_per_row, pady=10)


        # Score et chronomètre
        self.score_label = tk.Label(root, text="Score: 0")
        self.score_label.grid(row=self.calculate_rows() , column=0, columnspan=self.cards_per_row)

        self.timer_label = tk.Label(root, text="Temps écoulé: 0s")
        self.timer_label.grid(row=self.calculate_rows() + 1, column=0, columnspan=self.cards_per_row)

        # Initialiser le jeu
        self.reset_game()


    def stop_game(self):
        self.root.destroy()  # Fermer la fenêtre du jeu
        self.show_difficulty_selection()

    def show_difficulty_selection(self):
        start_window = tk.Tk()
        start_window.title("Sélectionnez le niveau de difficulté")

        difficulty_label = tk.Label(start_window, text="Sélectionnez le niveau de difficulté:")
        difficulty_label.pack(pady=10)

        difficulty_var = tk.StringVar()
        difficulty_var.set("debutant")

        difficulty_options = ["debutant", "intermediaire", "expert"]
        for option in difficulty_options:
            tk.Radiobutton(start_window, text=option.capitalize(), variable=difficulty_var, value=option).pack()

        start_button = tk.Button(start_window, text="Commencer le jeu", command=lambda win=start_window, diff_var=difficulty_var: start_game(win, diff_var.get()))
        start_button.pack(pady=20)

        start_window.mainloop()

    def calculate_rows(self):
        return len(self.cards) // self.cards_per_row

    def get_difficulty_enum(self):
        if self.difficulty == "debutant":
            return Difficulty.debutant
        elif self.difficulty == "intermediaire":
            return Difficulty.intermediaire
        elif self.difficulty == "expert":
            return Difficulty.expert
        else:
            return Difficulty.debutant

    def get_time_limit(self):
        if self.get_difficulty_enum() == Difficulty.debutant:
            return 60
        elif self.get_difficulty_enum() == Difficulty.intermediaire:
            return 45
        elif self.get_difficulty_enum() == Difficulty.expert:
            return 30
        else:
            return 60

    def flip_card(self, i, j):
        index = i * self.cards_per_row + j
        if self.start_time is None:
            self.start_time = time.time()

        if index not in self.flipped_cards and len(self.flipped_cards) < 2:
            # Retourner la carte avec l'image associée
            category = self.cards[index]
            tk_img = self.images[self.categories.index(category)]
            self.buttons[index].config(image=tk_img, state=tk.DISABLED)
            self.flipped_cards.append(index)

        if len(self.flipped_cards) == 2:
            self.root.after(1000, self.check_match)

    def check_match(self):
        idx1, idx2 = self.flipped_cards
        if self.cards[idx1] == self.cards[idx2]:
            messagebox.showinfo("Match", "Bonne correspondance!")
        else:
            # Cacher les cartes si ce ne sont pas des correspondances
            self.buttons[idx1].config(image=self.image_paths["?"], state=tk.NORMAL)
            self.buttons[idx2].config(image=self.image_paths["?"], state=tk.NORMAL)

        # Réinitialiser la liste des cartes retournées
        self.flipped_cards = []

        # Vérifier si toutes les cartes ont été trouvées
        if all(button.cget("state") == tk.DISABLED for button in self.buttons):
            elapsed_time = round(time.time() - self.start_time)
            self.display_end_game_message(elapsed_time)
            self.reset_game()

        # Mettre à jour le score et le chronomètre
        self.update_score()
        self.update_timer()

    def update_score(self):
        score = sum(button.cget("state") == tk.DISABLED for button in self.buttons)
        self.score_label.config(text=f"Score: {score}")

    def update_timer(self):
        elapsed_time = time.time() - self.start_time

        if elapsed_time >= self.get_time_limit():
            messagebox.showinfo("temps écoulé merci de recommencer"),
            return True
        else:
            self.timer_label.config(text=f"Temps écoulé: {elapsed_time:.2f}s / {self.get_time_limit():.2f}s")
            return False  # La partie n'est pas terminée

    def display_end_game_message(self, elapsed_time):
        if elapsed_time <= self.get_time_limit():
            messagebox.showinfo("Félicitations!", f"Vous avez trouvé toutes les correspondances!\nTemps écoulé: {elapsed_time:.2f}s\nScore Final: {self.calculate_final_score()}")
        else:
            messagebox.showinfo("Fin du jeu", f"Temps écoulé!\nVotre score final: {self.calculate_final_score()}\nEssayez à nouveau!")

    def calculate_final_score(self):
        score = sum(button.cget("state") == tk.DISABLED for button in self.buttons)
        time_bonus = max(0, (self.get_time_limit() - self.total_elapsed_time) // 5)
        final_score = score + time_bonus
        return final_score

    def reset_game(self):
        # Réinitialiser les cartes
        random.shuffle(self.cards)
        for button in self.buttons:
            button.config(image=self.image_paths["?"], state=tk.NORMAL)

        # Réinitialiser les variables de jeu
        self.flipped_cards = []
        self.start_time = time.time()
        self.total_elapsed_time = 0

        # Réinitialiser le score et le chronomètre
        self.update_score()
        self.update_timer()

def start_game(window, difficulty):
    window.destroy()

    root = tk.Tk()
    game = MemoryGame(root, difficulty)
    game.root.mainloop()

if __name__ == "__main__":
    start_window = tk.Tk()
    start_window.title("Sélectionnez le niveau de difficulté")

    difficulty_label = tk.Label(start_window, text="Sélectionnez le niveau de difficulté:")
    difficulty_label.pack(pady=10)

    difficulty_var = tk.StringVar()
    difficulty_var.set("debutant")

    difficulty_options = ["debutant", "intermediaire", "expert"]
    for option in difficulty_options:
        tk.Radiobutton(start_window, text=option.capitalize(), variable=difficulty_var, value=option).pack()

    start_button = tk.Button(start_window, text="Commencer le jeu", command=lambda win=start_window, diff_var=difficulty_var: start_game(win, diff_var.get()))
    start_button.pack(pady=20)

    start_window.mainloop()
