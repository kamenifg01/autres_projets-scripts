import tkinter as tk

'''tkinter._test()
root = tk.Tk()
label = tk.Label(root, text="Hello, Tkinter!",fg='black',bg='blue')
label.pack()
Button= tk.Button (root,text="fermer", command=root.destroy)
Button.pack()
root.mainloop()'''
root = tk.Tk()
canvas = tk.Canvas(root, width=200, height=200, background='green')
ligne = canvas.create_line(100,0,100,200,fill='red')
ligne2= canvas.create_line(0,100,200,100,fill='red')
txt=canvas.create_text(50,50,text='cible', font='Arial 16 italic', fill="blue")
canvas.pack()
root.mainloop()