from guess_modules import guessSecret

print(guessSecret(42,3))

