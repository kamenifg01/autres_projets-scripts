from gestioncompte import Compte
from gestioncompte import CompteCourant
from gestioncompte import CompteEpargne
from gestioncompte import Devise
from gestioncompte import Client
import csv

# Exemple d'utilisation
devise_euro = Devise("Euro")
compte1 = Compte(1, devise_euro, 1000.0)

print(f"Nombre de comptes créés: {Compte.nbrCompte}")
print(f"Solde du compte 1: {compte1.get_solde()}")

compte1.deposer(500.0)
compte1.retirer(200.0)

print(f"Solde final du compte 1: {compte1.get_solde()}")


# Exemple d'utilisation
devise_euro = Devise("Euro")
compte_epargne = CompteEpargne(1, devise_euro, 1000.0)

print(f"Plafond du compte épargne: {compte_epargne.get_plafond()}")
print(f"Taux du compte épargne: {compte_epargne.get_taux()}")

compte_epargne.deposer(2000.0)
interets = compte_epargne.calculer_interets()
print(f"Intérêts calculés: {interets}")


# Exemple d'utilisation
devise_dollar = Devise("Dollar")
compte_courant = CompteCourant(2, devise_dollar, 500.0)

print(f"Frais de découvert: {CompteCourant.get_fraisdecouvert()}")

decouvert_initial = compte_courant.get_decouvertautorise()
print(f"Découvert Autorisé initial: {decouvert_initial}")

compte_courant.set_decouvertautorise(-1500.0)
decouvert_modifie = compte_courant.get_decouvertautorise()
print(f"Découvert Autorisé modifié: {decouvert_modifie}")

print(compte_courant)


# Exemple d'utilisation
client1 = Client("Dupont", "Jean","abc123")
client2 = Client("Martin", "Sophie","def456")

devise_euro = Devise("Euro")
compte_courant = CompteCourant(1, devise_euro, 1000.0)
compte_epargne = CompteEpargne(2, devise_euro, 5000.0)

client1.ajouter_compte(compte_courant)
client1.ajouter_compte(compte_epargne)

compte_dollar = Compte(3, Devise("Dollar"), 200.0)
client2.ajouter_compte(compte_dollar)

# Écriture des clients dans un fichier CSV
with open('clients.csv', 'w', newline='') as csvfile:
    fieldnames = ['Nom', 'Prénom','Numero_id', 'Compte_Numéro', 'Compte_Devise', 'Compte_Solde']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()

    for client in [client1, client2]:
        for compte in client.comptes:
            writer.writerow({
                'Nom': client._nom,
                'Prénom': client._prenom,
                'Numero_id': client._numero_id,
                'Compte_Numéro': compte_courant._numero,
                'Compte_Devise':compte_courant._devise,
                'Compte_Solde': compte_courant._solde})

print("Données exportées avec succès dans 'clients.csv'.")
