import csv

class Devise:
    def __init__(self, nom):
        self._nom = nom


class Compte:
    nbrCompte = 0  # attribut statique

    def __init__(self, numero, devise, solde):
        self._numero = numero  # attribut avec protection d'encapsulation
        self._devise = devise  # attribut avec protection d'encapsulation
        self._solde = solde    # attribut avec protection d'encapsulation
        Compte.nbrCompte += 1  # Incrémente le nombre de comptes créés

    def deposer(self, montant):
        if montant > 0:
            self._solde += montant
            return True
        else:
            print("Le montant doit être positif.")
            return False

    def retirer(self, montant):
        if 0 < montant <= self._solde:
            self._solde -= montant
            return True
        else:
            print("Montant invalide ou solde insuffisant.")
            return False

    def get_solde(self):
        return self._solde






class CompteEpargne(Compte):
    _taux = 0.02  # attribut statique

    def __init__(self, numero, devise, solde, plafond=5000.0, taux=None):
        super().__init__(numero, devise, solde)
        self._plafond = plafond

        if taux is not None:
            CompteEpargne._taux = taux

    def get_plafond(self):
        return self._plafond

    def set_plafond(self, plafond):
        if plafond >= 0:
            self._plafond = plafond
        else:
            print("Le plafond doit être un nombre positif.")

    def get_taux(self):
        return CompteEpargne._taux

    def set_taux(cls, taux):
        if taux >= 0:
            CompteEpargne._taux = taux
        else:
            print("Le taux doit être un nombre positif.")
    set_taux = classmethod(set_taux)

    def calculer_interets(self):
        return self.get_solde() * CompteEpargne._taux




class CompteCourant(Compte):
    _fraisdecouvert = 15.0  # attribut statique

    def __init__(self, numero, devise, solde, decouvertAutorise=-1000.0):
        super().__init__(numero, devise, solde)
        self._decouvertautorise = decouvertAutorise


    def get_devise(self):
        return self._devise

    def set_devise(self, devise):
        self._devise= devise

    def get_numero(self):
        return self._numero

    def set_numero(self, numero):
        self._numero = numero


    def get_decouvertautorise(self):
        return self._decouvertautorise

    def set_decouvertautorise(self, decouvertAutorise):
        self._decouvertautorise = decouvertAutorise

    @staticmethod
    def get_fraisdecouvert():
        return CompteCourant._fraisdecouvert

    def __str__(self):
        return f"Compte Courant\nNuméro: {self._numero}\nDevise: {self._devise._nom}\nSolde: {self._solde}\nDecouvert Autorisé: {self._decouvertautorise}"





class Personne:
    def __init__(self, nom, prenom, numero_id):
        self._nom = nom
        self._prenom = prenom
        self._numero_id = numero_id


    def __str__(self):
        return f"{self._prenom} {self._nom} {self._numero_id}"

class Client(Personne):
    def __init__(self, nom, prenom, numero_id):
        super().__init__(nom, prenom, numero_id)
        self.comptes = []  # Liste des comptes du client


    def get_numero_id(self):
        return self._numero_id
    def set_numero_id(self, numero_id):
        self._numero_id = numero_id

    def ajouter_compte(self, compte):
        self.comptes.append(compte)

    def __str__(self):
        compte_str = "\n".join([f"  - {compte}" for compte in self.comptes])
        return f"Client: {super().__str__()} \nComptes:\n{compte_str}"
